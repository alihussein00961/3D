<?php include_once "meta_data.php";?>
    <div class="pos-f-t "style="position:fixed; width: 100vw;">
        <nav class="navbar navbar-dark bg-dark">
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
            </button>
			<div>
				<?php
//				print_r($_SESSION['user_loggedIn']);
				if ($_SESSION['user_loggedIn']=='' || $_SESSION['user_loggedIn']!=''){
					echo '<a href="login.php" class="navBar_login_register">LogIn /</a>';
					echo '<a href="sign_up.php" class="navBar_login_register">Register</a>';
					}else{}
//				else {
//					echo '<a href="index.php?clicked"> ' . "Log out" . '</a>';
//					if (isset($_GET['clicked'])) {
//						$_SESSION['user_loggedIn'] = '';
//						unset($_SESSION['user_loggedIn']);
//						session_destroy();
//						header("Location: index.php");
//					}
//				}
				 ?>
			</div>
		</nav>
		<div class="collapse" id="navbarToggleExternalContent">
            <div class="bg-dark">
                <div id="navBar_options" style="background-color: blue;">
                    <div><a href="index.php">Home</a></div>
                    <div><a href="#">About Us</a></div>
                    <div><a href="#">Download</a></div>
                    <div><a href="#">Support</a></div>
                </div>
            </div>
		</div>
	</div>

<?php
//if ($_SESSION['instructor']!=''){
//	echo '<a href="index.php" class="active">Home</a>';
//	echo '<a href="instructorProfile.php">' . print_r($_SESSION['instructor'],true) . '</a>';
//	echo '<a href="settings.php">' ."Settings".'</a>';
//	echo '<a href="index.php?clicked"> ' ."Log out" . '</a>';
//	if (isset($_GET['clicked'])){
//		session_destroy();
//		$_SESSION['instructor']='';
//		header("Location: index.php");
//	}
//} else{
//	if(isset($_SESSION['logIn'])!=''){
//		echo '<a href="user_books.php">' . "Books" . '</a>';
//		echo '<a href="user_software_section.php">' . "Software's" . '</a>';
//		echo '<a href="members_profile.php"> ' . print_r($_SESSION['user'],true) . '</a>';
//		echo '<a href="index.php?clicked"> ' ."Log out" . '</a>';
//		if (isset($_GET['clicked'])){
//			session_destroy();
//			$_SESSION['logIn']='';
//			header("Location: index.php");
//		}
//	} else{
//		echo '<a href="index.php" class="active">Home</a>';
//		echo '<a href="students_logIn.php">' . "Members" . '</a>';
//		echo '<a href="instructors_logIn.php">' . "Admin" . '</a>';
//		echo '<a href="about_us.php">' ."About Us".'</a>';
//	}
//}
//?>


<style>
    #navBar_options div{
        z-index: 1;
        display: block;
        text-decoration: none;
        margin: auto;
        text-align: center;
        background-color: #343a40;
        width: 25%;
        float: left;
        color: #f2f2f2;
        padding: 14px 16px;
        font-size: 17px;
    }

    /*#navBar_options div:hover{*/
    /*    background-color: lightgray;*/
    /*    color: #000000;*/
    /*    text-decoration: none;*/
    /*}*/
</style>
