<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>3D Heroes</title>
	<link rel="stylesheet" href="css/index.css">
	<?php include_once "meta_data.php";?>
</head>
<body>
<header>
	<?php include_once "navBar.php";?>
</header>
<main>
	<div class="flex-container middle" style="margin-bottom:5rem;">
		<div class="card">
			<img src="assets/img/test.png">
			<a href="congratulations.php"><h1>3D Printing</h1></a>
		</div>

		<div class="card">
			<img src="assets/img/test.png">
			<a href="congratulations.php"><h1>Material Supply</h1></a>
		</div>
	</div>
	<div id="donate_button">
		<button type="button" class="btn btn-primary btn-lg btn-block">I CAN DONATE</button>
	</div>
</main>

<footer>
	<div>
		<p id="copy_right">&copy; All Rights Reserved | 3D Heroes</p>
		<ul class="icons">
			<li><a href="#" target="_blank">Maps</a></li>
			<li><a href="#" target="_blank">Instagram</a></li>
			<li><a href="mailto:superokk@suport.com"target="_blank">Email</a></li>
			<li><a href="#" target="_blank">Facebook</a></li>
		</ul>
	</div>
</footer>
</body>

</html>

<style>
	body{}

	a{
		color: white;
	}

main div{
	padding-top: 3rem;
}

	.card {
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
		max-width: 300px;
		margin: 4rem auto 1rem;
		text-align: center;
	}

	.card h1{
		padding: 2rem;
		color: #000000;
	}

	#donate_button{
		width: 20%;
		margin: auto;
		padding-bottom: 2rem;
	}

	/*.card:hover{*/
	/*    box-shadow: 2px 4px 8px 2px rgba(.5, .5, .5, 0.2);*/
	/*    background-color: #343a40;*/
	/*    color: white;*/
	/*}*/

	.title {
		color: grey;
		font-size: 18px;
	}

	.flex-container{
		display: flex;
		flex-wrap: wrap;
		margin-bottom: 2rem;
		margin-right: 2rem;
	}

	/*footer div{*/
	/*	position: fixed;*/
	/*	left: 0;*/
	/*	bottom: 100vh;*/
	/*	width: 100%;*/
	/*	display: block;*/
	/*}*/

	footer div{
		position: absolute;
		display: block;
		width: 100vw;
		float: right;
		background-color: #343a40;
	}
	footer li{
		padding-top: 1rem;
		float: right;
		position: relative;
		color: white;
		text-align: center;
		display: inline-block;
		overflow: hidden;
		vertical-align: top;
		width: 10%;
	}

	footer p{
		color: white;
		padding-left: 4rem;
	}

	#copy_right{
		padding-top: 1rem;
		float: left;
		width: 20%;
	}
</style>