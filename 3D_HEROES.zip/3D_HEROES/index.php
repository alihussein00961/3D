<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>3D Heroes</title>
    <link rel="stylesheet" href="css/index.css">
	<?php include_once "meta_data.php";?>
</head>
<body>
<header>
	<?php include_once "navBar.php";?>
</header>
<main>
    <!--Main Viewed Page--->
    <div id="main-window">
        <div id="img-bg">
            <img src="assets/img/bgimg_2.jpeg" style="background-image: none; width: 100vw; height: 100vh;">
        </div>
        <div id="main-window-footer">
            <div id="icon">
                <a href="#big_dream"><img src="assets/img/arrowdown2.png" style="width: 60px; height: 60px;" id="arrow_down"></a>
            </div>
        </div>
    </div>

    <h1 id="big_dream">The Big Dream</h1>
    <div class="flex-container middle" style="margin-bottom:5rem;">
        <div class="card">
            <a href="supply.php"><h1>I can Help My Country</h1></a>
        </div>

        <div class="card">
            <a href="order_shields.php"><h1>We Need Face Shields</h1></a>
        </div>
    </div>
</main>

<footer>
    <div>
        <p id="copy_right">&copy; All Rights Reserved | 3D Heroes</p>
        <ul class="icons">
            <li><a href="#" target="_blank">Maps</a></li>
            <li><a href="#" target="_blank">Instagram</a></li>
            <li><a href="mailto:superokk@suport.com"target="_blank">Email</a></li>
            <li><a href="#" target="_blank">Facebook</a></li>
        </ul>
    </div>
</footer>
</body>

</html>

<style>
    body{}

    a{
        color: white;
    }

    #back-img{
        z-index: 0;
        width: 100vw;
        height: 100vh;
    }

    #bg-img img{
        display: block;
        width: 100vw;
        height: 100vh;
        background-size: cover;
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-position: center;
    }


    main #main-window {
        background-color: darkred;
        width: 100vw;
    }

    #main-window-footer {
        width: 80vw;
        text-align: center;
        /*//padding: .5rem;*/
        position: absolute;
        font-size: 250%;
        top: 95%;
        left: 50%;
        transform: translate(-50%, -50%);
        color: white;
        padding-bottom: 1rem;
    }

    #icon {
        padding-bottom: .5rem;
    }

    a {
        font-weight: bold;
        color: white;
    }


    #icon #test:hover {
        animation-name: example;
        animation-duration: 1s;
    }

    @keyframes example {
        0% {
            margin-top: 0;
        }
        50% {
            margin-top: .5rem;
        }
        100% {
            margin-top: 1rem;
        }
    }

    #big_dream{
        text-align: center;
        padding-top: 2rem;
        font-size: 60px;
    }

    .card {
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
        max-width: 300px;
        margin: 4rem auto 1rem;
        text-align: center;
    }

    .card h1{
        padding: 2rem;
        color: #000000;
    }

    /*.card:hover{*/
    /*    box-shadow: 2px 4px 8px 2px rgba(.5, .5, .5, 0.2);*/
    /*    background-color: #343a40;*/
    /*    color: white;*/
    /*}*/

    .title {
        color: grey;
        font-size: 18px;
    }

    .flex-container{
        display: flex;
        flex-wrap: wrap;
        margin-bottom: 2rem;
        margin-right: 2rem;
    }


    footer div{
        position: absolute;
        display: block;
        width: 100vw;
        float: right;
        background-color: #343a40;
    }
    footer li{
        padding-top: 1rem;
        float: right;
        position: relative;
        color: white;
        text-align: center;
        display: inline-block;
        overflow: hidden;
        vertical-align: top;
        width: 10%;
    }

    footer p{
        color: white;
        padding-left: 4rem;
    }

    #copy_right{
        padding-top: 1rem;
        float: left;
        width: 20%;
    }
</style>