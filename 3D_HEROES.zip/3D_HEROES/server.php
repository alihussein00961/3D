<?php

include_once "connect_database.php";

//*****************************************************************************************************************
//*****************************************************************************************************************
//*****************************************************************************************************************
//*****************************************************************************************************************
//*****************************************************************************************************************


//Create  Accounts
if (isset($_POST['register'])){
	//receive all input values from the form
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$fullName = mysqli_real_escape_string($conn, $_POST['fullName']);
	$username = mysqli_real_escape_string($conn,$_POST['userName']);
	$phoneNumber = mysqli_real_escape_string($conn,$_POST['phoneNumber']);
	$area = mysqli_real_escape_string($conn, $_POST['area']);
	$password_1 = mysqli_real_escape_string($conn, $_POST['password-1']);
	$password_2 = mysqli_real_escape_string($conn, $_POST['password-2']);

	// form validation: ensure that the form is correctly filled ...
	// by adding (array_push()) corresponding error unto $errors array
	if (empty($email) || empty($fullName) || empty($username) || empty($phoneNumber) ||empty($area)  || empty($password_1) || empty($password_2)) {
		array_push($errors, "Please fill all the fields");
	}

	if ($password_1 != $password_2) {
		array_push($errors, "The two passwords doesn't Match");
	}

	if (preg_match('/[a-zA-Z0-9\ ]{3,}$/',$fullName)){
		// first check the database to make sure
		// a user does not already exist with the same username and/or email
		$user_check_query = "SELECT * FROM users WHERE email='$email'";
		$result = mysqli_query($conn, $user_check_query);

		$user_check_query1 = "SELECT * FROM users WHERE username='$username'";
		$result1 = mysqli_query($conn, $user_check_query1);

		if (mysqli_num_rows($result)>0) { // if user exists
			array_push($errors, "Email already exists");
		} else if (mysqli_num_rows($result1)>0){
			array_push($errors, "UserName already exists");
		} else {
			// Finally, register user if there are no errors in the form
			if (count($errors) == 0) {
				$password = crypt($password_1, 'nIHjHVQAxYQqCEvvnGNoOwgeItSwoWwkDanXhEcz');
				//encrypt the password before saving in the database

				$query = "INSERT INTO users (fullName, username, email, phoneNumber, area, password) 
  			  VALUES('$fullName','$username','$email','$phoneNumber','$area','$password')";
				if (mysqli_query($conn, $query)){
					array_push($errors, "Account Created Successfully\nPlease LogIn");
					header("location: index.php");
				}else{
					array_push($errors, "Connection Error!");
				}
//
//				mail($email,"Society Of Engineering","
//				Your Account is created Successfully
//				\nEmail: {$email}
//				\nPassword: {$password_1}
//				\nID: {$ID}
//				\nFull Name: {$fullName}
//				\nMajor: {$major}
//				\nMobile Number: {$mobileNumber}
//				\nPlease Change Your Password Immediately after your logIn, As a Member.\n
//				\nPlease Keep this Email in your INBOX for future Society Membership reference.\n
//				\nwww.soelib.com
//				\nThank you,\nFor your Registration.
//				\nBest regards,
//				\nSociety Of Engineering","Society of Engineering");
			}
		}
	}else{
		array_push($errors, "Please check your username or password");
	}
}



//*****************************************************************************************************************
//*****************************************************************************************************************
//*****************************************************************************************************************
//*****************************************************************************************************************
//*****************************************************************************************************************


//Admin LogIn
if (isset($_POST['logIn_user']))
{
	$username = mysqli_real_escape_string($conn, $_POST['username']);
	$password = mysqli_real_escape_string($conn, $_POST['password']);

	if (empty($username) || empty($password) ) {
		array_push($errors, "Please fill all the fields");
	}

	if (count($errors) == 0) {
		$passwordEncrypted = crypt($password, 'nIHjHVQAxYQqCEvvnGNoOwgeItSwoWwkDanXhEcz');
		$rsUsers = mysqli_query($conn, "SELECT * FROM users WHERE username = '" . $username . "' AND  password = '" . $passwordEncrypted . "'");
		$numUsers = mysqli_num_rows($rsUsers);

//		$queryget1 = mysqli_query($conn,"SELECT puEmail FROM admin WHERE username = '$username'")or die ("Query didnt work");
//		$row = mysqli_fetch_assoc($queryget1);
//		$instructor_Email = $row['puEmail'];

		if ($numUsers == 0) {
			array_push($errors, "Please check your username or password");
		} else {
//			$sql = "SELECT * FROM students";
//			$connStatus = $conn->query($sql);
//			$numberOfRows = mysqli_num_rows($connStatus);
//
//			$sql1 = "SELECT * FROM books";
//			$connStatus1 = $conn->query($sql1);
//			$numberOfBooks = mysqli_num_rows($connStatus1);
//
//			$result = mysqli_query($conn,'SELECT SUM(nbOfDownloads) AS value_sum FROM books');
//			$row = mysqli_fetch_assoc($result);
//			$sum = $row['value_sum'];
//
//			$_SESSION['nbofbooksDownloaded'] = $sum;
//			$_SESSION['numberOfBooks'] = $numberOfBooks;
//			$_SESSION['userNumber'] = $numberOfRows;
//			$_SESSION['instructor'] = $username;
//			$_SESSION['successs'] = "You are now logged in";
//			$_SESSION['inst_Email'] = $instructor_Email;
//
//			$pass_length ='';
//			$j = strlen($_POST['password']);
//			for ($i=0; $i<$j; $i++){
//				$pass_length.='.';
//			}
//			$_SESSION['inst_password'] = $pass_length;
//			session_regenerate_id();
			$_SESSION['user_loggedIn'] = "loggedIn";
			header('Location: logged_into.php');
		}
	}
}