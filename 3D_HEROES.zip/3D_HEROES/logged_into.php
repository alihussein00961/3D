<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>3D Heroes</title>
	<link rel="stylesheet" href="css/index.css">
	<?php include_once "meta_data.php";?>
</head>
<body>
<header>
	<?php include_once "navBar.php";?>
</header>
<main>
	<a href="index.php"><h1 id="big_dream" style="color:red; padding: 6rem;">Logout</h1></a>
</main>
</body>

</html>