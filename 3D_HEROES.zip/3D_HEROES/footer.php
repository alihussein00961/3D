<div>
	<p>Call</p>
	<p>Email</p>
	<p>Facebook</p>
	<p>Instagram</p>
</div>
<?php
