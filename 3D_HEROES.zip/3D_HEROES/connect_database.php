<?php

session_start();

$servername = "localhost:8889";
$server_user = "root";
$server_user = "root";
$dbname = "3dHeroes";

//for saving errors in order to be displayed
$errors = array();

// Create connection
$conn = mysqli_connect($servername, $server_user, $server_user, $dbname);

// Check connection
if (!$conn) {
	array_push($errors, "Connection failed");
}else{}

?>