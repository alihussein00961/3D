<?php require_once "server.php";?>
<!DOCTYPE html>
<html lang="en">
<head>
	<?php include_once "meta_data.php";?>
</head>
<body>

<header>
	<?php include_once "navBar.php"; ?>
</header>

<main>
	<div id="form">
		<div id="pu-logo">
<!--			<a href="index.php"><img src="img/SOELogo.jpg"></a>-->
		</div>

		<div id="formFields">
			<form action="" method="post">
				<?php include('errors.php'); ?>
				<h3>LogIn</h3>
				<div class="form-group">
					<label for="exampleInputEmail1"><i>UserName</i></label>
					<input type="text" class="form-control" id="InputEmail" name="username" value="<?php echo isset($_POST['username']) ? $_POST['username'] : '' ?>" aria-describedby="emailHelp" placeholder="Username" required autofocus>
				</div>
				<div class="form-group">
					<label for="exampleInputPassword1"><i>Password</i></label>
					<input type="password" class="form-control" id="InputPassword" name="password" value="<?php echo isset($_POST['password']) ? $_POST['password'] : '' ?>" maxlength="15" placeholder="Password" required>
				</div>
				<div class="form-button">
                    <div style="text-align: center;">
                        <a href="#">Forgot Password?</a>
                    </div>
					<button type="submit" class="btn btn-primary" name="logIn_user" style="width: 100%; margin-top:1rem;">Log In</button>
				</div>
				<div id="copyRights">
					<p>&copy; All Rights Reserved | 3D Heroes</p>
				</div>
			</form>
		</div>
	</div>
</main>
</body>
</html>

<style>
	*{
		padding: 0;
		margin: 0;
		background-color: #343a40;
	}

	main {
		width: 100vw;
		height: 100vh;
	}

	#form{
        padding-top: 4rem;
		margin: auto;
		width:60vw;
		height:100vh;
	}

	#pu-logo img{
		display: block;
		margin: 3rem auto 3rem auto;
	}

	#formFields {
        padding-top: 3rem;
		width: 80%;
		margin: auto;
	}

	#emailHelp i,b{
		color: white;
	}

	h3{
		font-style:italic;
		text-align: center;
		color: white;
		padding-top: 2rem;
		padding-bottom: 2rem;
	}

	.form-group{
		padding: 1.5rem .5rem 1.5rem .5rem;
		color: white;
		text-align: center;
	}

	small{
		color: white;
	}

	.form-check{
		color: white;
		text-align: center;
	}

	.form-button {
		color: white;
		width: 40%;
		padding-top: .8rem;
		padding-bottom: 1.8rem;
		margin-left: auto;
		margin-right: auto;
	}


	#form #copyRights {
		text-align: center;
		margin-left: auto;
		margin-right: auto;
		width: 100%;
		color: white;
		padding-top: 1rem;
		padding-bottom: 1rem;

	}

	#form #forgot-Password{
		text-align: center;
		margin-left: auto;
		margin-right: auto;
		width: 100%;
		text-decoration: underline;
		padding-bottom: 1rem;
	}

</style>