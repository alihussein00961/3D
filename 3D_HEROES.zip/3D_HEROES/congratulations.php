<!DOCTYPE html>
<html lang="en">
<head>

	<?php include_once "meta_data.php";?>

</head>
<body>
<header>
	<?php session_start();
	include_once('navBar.php');?>
</header>

<main>
	<div class="container" style="margin-bottom: 5rem; padding-top: 6rem !important;">
		<div class="card" style="margin-top: 3rem;">

			<div class="card-body" style="background-color:#343a40; color: white; padding-top: 2rem;">
				<div style="text-align: center">
					<h1>CONGRATULATIONS<br>HEROES!</h1>
				</div>

				<div style="text-align: center;">
					<br><br>
					<h1>Your are now a member of the family</h1>
				</div>

				<div id="donate_button" style="padding-top: 4rem; padding-bottom: 2rem;">
					<button type="button" class="btn btn-primary btn-lg btn-block">Let's Starts</button>
				</div>

			</div>
			<style>
				.container{
					margin-bottom: 4rem;
				}

				.img-cont img{
					width: 35% !important;
				}

				#modalWindow2 {
					position: fixed;
					font-family: arial,helvetica, sans-serif;
					top: 0;
					right: 0;
					bottom: 0;
					left: 0;
					background: rgba(0, 0, 0, 0.4);
					z-index: 99999;
					opacity:0;
					transition: opacity 400ms linear;
					pointer-events: none;
				}

				#modalWindow2:target {
					opacity:1;
					pointer-events: auto;
				}

				#modalWindow2 > div {
					width: 30vw;
					height: 50vh;
					position: relative;
					margin: 5% auto;
					padding: 20px 20px 13px 20px;
					border: solid;
					border-color: black;
					border-width : 2px;
					background: darkred;
					border-radius: 10px;
				}

				#modalWindow2 p{
					color: white;
				}

				@media screen and (max-width: 1000px) {
					#modalWindow1 > div{
						width: 80vw;
						height: 40vh;
					}

					#modalWindow2 > div {
						width: 90vw;
						height: 65vh;
					}
					.container{
						margin-bottom: 7rem;
					}
				}
			</style>
		</div>
	</div>
</main>

<footer>

</footer>


</body>
</html>