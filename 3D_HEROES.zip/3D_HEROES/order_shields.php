<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>3D Heroes</title>
	<?php include_once "meta_data.php";?>
</head>
<body>
<header>
	<?php include_once "navBar.php";?>
</header>
<main>
	<div id="form" style="padding-top: 7rem;">
		<p style="text-align: center; color: white; text-decoration: underline; font-weight: bold; font-style: italic; font-size: 2rem;">Order Shields</p>
		<div id="formFields">
			<form>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">Full Name</label>
						<input type="email" class="form-control" id="inputEmail4" placeholder="Full Name">
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">Institution Name</label>
						<input type="password" class="form-control" id="inputPassword4" placeholder="Institution Name">
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">Email</label>
						<input type="email" class="form-control" id="inputEmail4" placeholder="Email">
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">Other</label>
						<input type="number" class="form-control" id="inputPassword4" placeholder="Other">
					</div>
				</div>
				<div class="form-group">
					<label for="inputAddress">Address 1</label>
					<input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St">
				</div>
				<div class="form-group">
					<label for="inputAddress2">Address 2</label>
					<input type="text" class="form-control" id="inputAddress2" placeholder="Apartment, studio, or floor">
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputCity">City</label>
						<input type="text" class="form-control" id="inputCity">
					</div>
					<div class="form-group col-md-4">
						<label for="inputState">Phone Number</label>
						<input type="number" class="form-control" id="inputCity" placeholder="Phone Number">
					</div>
					<div class="form-group col-md-2">
						<label for="inputZip">Nb of Face Shields</label>
						<input type="number" class="form-control" id="inputZip" placeholder="Nb of Face Shields">
					</div>
				</div>
				<div class="form-group">
					<div class="form-check">
						<input class="form-check-input" type="checkbox" id="gridCheck">
						<label class="form-check-label" for="gridCheck" style="padding-right: 3rem;">
							Medical Purposes
						</label>

						<input class="form-check-input" type="checkbox" id="gridCheck">
						<label class="form-check-label" for="gridCheck">
							Personal Purposes
						</label>

					</div>
                    <div style="padding: 1.5rem; font-size: 20px; font-weight: bold;">
						<a href="#">Find 3D Printers Owners!</a>
					</div>
					<button type="submit" class="btn btn-primary" style="margin: 1rem auto; text-align: center;">Order</button>

				</div>
			</form>
		</div>
	</div>
</main>

<footer>
	<div>
		<p id="copy_right">&copy; All Rights Reserved | 3D Heroes</p>
		<ul class="icons">
			<li><a href="#" target="_blank">Maps</a></li>
			<li><a href="#" target="_blank">Instagram</a></li>
			<li><a href="mailto:superokk@suport.com"target="_blank">Email</a></li>
			<li><a href="#" target="_blank">Facebook</a></li>
		</ul>
	</div>
</footer>
</body>

</html>

<style>
	*{
		padding: 0;
		margin: 0;
		background-color: #343a40;
	}

	#form #pu-logo img{
		display: block;
		margin-top: 1rem;
		margin-left: auto;
		margin-right: auto;
		padding-bottom: .8rem;
		width: 10%;
	}

	label{
		font-weight:bold;
		font-style: italic;
	}

	#formFields {
		width: 60%;
		margin-right: auto;
		margin-left: auto;
	}

	#emailHelp i,b{
		color: white;
	}

	.form-group{
		padding: .5rem;
		color: white;
		text-align: center;
	}

	small{
		color: white;
	}

	/*#registerButton{*/
	/*	padding: .5rem;*/
	/*}*/

	/*.form-button {*/
	/*	color: white;*/
	/*	width: 30%;*/
	/*	padding-top: .8rem;*/
	/*	padding-bottom: 1.8rem;*/
	/*	margin-left: auto;*/
	/*	margin-right: auto;*/
	/*}*/

	footer div{
		position: absolute;
		display: block;
		width: 100vw;
		float: right;
		background-color: #343a40;
	}
	footer li{
		padding-top: 1rem;
		float: right;
		position: relative;
		color: white;
		text-align: center;
		display: inline-block;
		overflow: hidden;
		vertical-align: top;
		width: 10%;
	}

	footer p{
		color: white;
		padding-left: 4rem;
	}

	#copy_right{
		padding-top: 1rem;
		float: left;
		width: 20%;
	}


	@media screen and (max-width: 600px) {
		.form-button button{
			width: 140% !important;
		}
	}

</style>