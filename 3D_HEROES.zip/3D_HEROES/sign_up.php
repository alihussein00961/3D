<?php require_once "server.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<?php include_once "meta_data.php";?>
</head>
<body>

<header>
    <?php include_once "navBar.php"; ?>
</header>

<main>
	<div id="form" style="padding-top: 6rem;">
		<p style="text-align: center; color: white; text-decoration: underline; font-weight: bold; font-style: italic; font-size: 2rem;"><a href="index.php" style="color: white;">Register</a></p>
		<div id="formFields">
			<form action="sign_up.php" method="post">
				<?php include('errors.php'); ?>
				<div class="form-group" style="padding-top: 1rem;">
					<label for="exampleInputEmail1">Email Address</label>
					<input type="email" class="form-control" name="email" id="InputEmail"  value="<?php echo isset($_POST['email']) ? $_POST['email'] : '' ?>" aria-describedby="emailHelp" placeholder="Enter email" required
						   autofocus>
				</div>
				<div class="form-group">
					<label for="exampleInputUsername1">Full Name</label>
					<input type="text" class="form-control" name="fullName" value="<?php echo isset($_POST['fullName']) ? $_POST['fullName'] : '' ?>" id="InputUserName" placeholder="Full Name" required>
				</div>
                <div class="form-group">
                    <label for="exampleInputUsername1">UserName</label>
                    <input type="text" class="form-control" name="userName" value="<?php echo isset($_POST['userName']) ? $_POST['userName'] : '' ?>" id="InputUserUserName" placeholder="UserName" required>
                </div>
                <div class="form-group">
                    <label for="exampleInputUsername1">Phone Number</label>
                    <input type="number" class="form-control" name="phoneNumber" value="<?php echo isset($_POST['phoneNumber']) ? $_POST['phoneNumber'] : '' ?>" id="InputUserUserName" placeholder="Phone Number" required>
                </div>
				<div class="form-group">
					<label for="exampleInputUsername1">Area</label>
					<select id="inputState" class="form-control" name="area" required>
						<option selected value="<?php echo isset($_POST['area']) ? $_POST['area'] : '' ?>" disabled>Choose Your Area...</option>
						<option>Beirut</option>
						<option>Tripoli</option>
						<option>Sidon</option>
                        <option>Zahle</option>
                        <option>Tyre</option>
                        <option>Jounieh</option>
                        <option>Baalbek</option>
                        <option>Byblos</option>
                        <option>Nabatieh</option>
                    </select>
				</div>
				<div class="form-group">
					<label for="exampleInputPassword1">Password</label>
					<input type="password" class="form-control" name="password-1"  value="<?php echo isset($_POST['password-1']) ? $_POST['password-1'] : '' ?>" id="InputPassword" placeholder="Password" required>
				</div>
				<div class="form-group">
					<label for="exampleInputPassword1">Confirm Password</label>
					<input type="password" class="form-control" name="password-2" value="<?php echo isset($_POST['password-2']) ? $_POST['password-2'] : '' ?>" id="InputPassword" placeholder="Confirm Password" required>
				</div>
				<div class="form-button">
					<button type="submit" class="btn btn-primary" name="register" id="registerButton" style="width: 100%; margin-top: 1rem;">Register</button>
				</div>
				<div id="copyRights">
					&copy; All Rights Reserved | 3D Heroes
				</div>
			</form>
		</div>
	</div>
</main>

</body>
</html>

<style>
	*{
		padding: 0;
		margin: 0;
        background-color: #343a40;
	}

	#form #pu-logo img{
		display: block;
		margin-top: 1rem;
		margin-left: auto;
		margin-right: auto;
		padding-bottom: .8rem;
		width: 10%;
	}

	label{
		font-weight:bold;
		font-style: italic;
	}

	#formFields {
		width: 60%;
		margin-right: auto;
		margin-left: auto;
	}

	#emailHelp i,b{
		color: white;
	}

	.form-group{
		padding: .5rem;
		color: white;
		text-align: center;
	}

	small{
		color: white;
	}

	#registerButton{
		padding: .5rem;
	}

	.form-button {
		color: white;
		width: 30%;
		padding-top: .8rem;
		padding-bottom: 1.8rem;
		margin-left: auto;
		margin-right: auto;
	}

	#copyRights {
		text-align: center;
		margin-left: auto;
		margin-right: auto;
		width: 100%;
		color: white;
		padding-top: 1rem;
		padding-bottom: 1rem;
	}

	@media screen and (max-width: 600px) {
        .form-button button{
			width: 140% !important;
		}
	}

</style>